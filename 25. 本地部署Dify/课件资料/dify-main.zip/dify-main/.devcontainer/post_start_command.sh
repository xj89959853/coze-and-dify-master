#!/bin/bash

cd api && uv sync
