# Tencent trace entities module
