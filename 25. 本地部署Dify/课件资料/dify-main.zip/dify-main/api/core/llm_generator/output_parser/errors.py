class OutputParserError(ValueError):
    pass
